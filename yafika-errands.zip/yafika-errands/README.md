# 🚀 Yafika Errands

Lusaka's trusted errand and delivery service app.

## Deploy to Vercel (Step-by-Step)

### Option A — GitHub + Vercel (Recommended)

1. Create a free account at https://github.com
2. Create a new repository called `yafika-errands`
3. Upload all these files into the repository
4. Go to https://vercel.com and sign up (use your GitHub account)
5. Click "Add New Project" → Import your `yafika-errands` repo
6. Vercel auto-detects React — just click **Deploy**
7. Your app goes live at: `https://yafika-errands.vercel.app`

### Option B — Vercel CLI (Terminal)

```bash
npm install -g vercel
cd yafika-errands
npm install
vercel
```

Follow the prompts — done in 2 minutes!

## Run Locally

```bash
npm install
npm start
```

Opens at http://localhost:3000

## Admin PIN
Default PIN to access the admin panel: **1234**
