import React, { useState } from "react";

const C = {
  p900:"#1E0845", p800:"#3D1278", p700:"#5B21B6", p600:"#7C3AED",
  p500:"#8B5CF6", p400:"#A78BFA", p300:"#C4B5FD", p100:"#EDE9FE", p50:"#F5F3FF",
  gold:"#F59E0B", goldD:"#D97706", goldL:"#FEF3C7",
  white:"#FFFFFF", dark:"#1C1028", gray:"#6B7280", lightG:"#F3F4F6",
  success:"#10B981", warning:"#F59E0B", danger:"#EF4444",
};

const STATUS = {
  pending:       {bg:"#FEF3C7", text:"#92400E", dot:C.warning},
  "in-progress": {bg:"#DBEAFE", text:"#1E40AF", dot:"#3B82F6"},
  completed:     {bg:"#D1FAE5", text:"#065F46", dot:C.success},
  cancelled:     {bg:"#FEE2E2", text:"#991B1B", dot:C.danger},
};

const PAY = [
  {id:"mtn",    label:"MTN Mobile Money",   icon:"📱", bg:"#FFCC00", fg:"#1a1a1a", ussd:"*321#"},
  {id:"airtel", label:"Airtel Money",       icon:"📲", bg:"#E8001C", fg:"#ffffff", ussd:"*778#"},
  {id:"zamtel", label:"Zamtel Kwacha",      icon:"💚", bg:"#009933", fg:"#ffffff", ussd:"*422#"},
  {id:"card",   label:"Credit / Debit Card",icon:"💳", bg:"#1A56DB", fg:"#ffffff", ussd:""},
];

const ITEMS = ["Groceries","Medicines","Electronics","Clothing","Documents","Food / Takeaway","Books","Household Items","Other"];
const SPOTS = ["Soweto Market","Shoprite Manda Hill","Shoprite Levy","Kulima Tower","Cairo Road","UTH Pharmacy","Lusaka Central Market","Arcades Shopping Centre"];

const DFEES = [
  {label:"Same area (0 – 3 km)",   fee:30},
  {label:"Short (3 – 8 km)",       fee:60},
  {label:"Medium (8 – 15 km)",     fee:100},
  {label:"Long (15 km +)",         fee:150},
];

const SAMPLE = [
  {id:1,orderNo:"YE-001",clientName:"Chanda Mwale", clientPhone:"0977112233",
   items:[{name:"Groceries",qty:1,notes:"Tomatoes, onions, kapenta"}],
   pickupLocation:"Soweto Market",deliveryAddress:"Plot 14, Woodlands Extension",
   status:"completed",  itemAmount:120,itemUnknown:false,deliveryFee:60, payMethod:"mtn",   time:"2026-03-15 10:30"},
  {id:2,orderNo:"YE-002",clientName:"Bwalya Tembo",  clientPhone:"0966223344",
   items:[{name:"Medicines",qty:1,notes:"Paracetamol, Amoxicillin"}],
   pickupLocation:"UTH Pharmacy",deliveryAddress:"Flat 5B, Avondale Flats",
   status:"in-progress",itemAmount:55, itemUnknown:false,deliveryFee:60, payMethod:"airtel",time:"2026-03-18 09:00"},
  {id:3,orderNo:"YE-003",clientName:"Mutale Phiri",  clientPhone:"0955334455",
   items:[{name:"Documents",qty:1,notes:"NRC from passport office"}],
   pickupLocation:"Passport Office, Haile Selassie Rd",deliveryAddress:"House 7, Kabulonga Road",
   status:"pending",    itemAmount:0,  itemUnknown:true, deliveryFee:100,payMethod:"card",  time:"2026-03-19 08:00"},
];

// ── tiny helpers ──────────────────────────────────────────────
const IS = (x={}) => ({width:"100%",padding:"11px 14px",borderRadius:8,border:`1.5px solid ${C.p300}`,
  fontSize:14,fontFamily:"'Trebuchet MS',sans-serif",boxSizing:"border-box",
  outline:"none",background:"#fff",color:C.dark,...x});
const LS = {display:"block",fontSize:11,fontWeight:700,color:C.p700,
  fontFamily:"'Trebuchet MS',sans-serif",marginBottom:5,textTransform:"uppercase",letterSpacing:.8};
const PB = (bg,fg=C.white,x={}) => ({background:bg,color:fg,border:"none",borderRadius:12,
  padding:"13px 20px",fontSize:15,fontWeight:700,cursor:"pointer",
  fontFamily:"'Trebuchet MS',sans-serif",width:"100%",...x});

// ── main app ──────────────────────────────────────────────────
export default function App() {
  const [view,     setView]     = useState("home");
  const [aTab,     setATab]     = useState("dashboard");
  const [orders,   setOrders]   = useState(SAMPLE);
  const [sel,      setSel]      = useState(null);
  const [toast,    setToast]    = useState(null);
  const [pin,      setPin]      = useState("");
  const [pinErr,   setPinErr]   = useState(false);

  // client form
  const [step,     setStep]     = useState(1);
  const [oItems,   setOItems]   = useState([{name:"",qty:1,notes:""}]);
  const [pickup,   setPickup]   = useState("");
  const [delivery, setDelivery] = useState("");
  const [cName,    setCName]    = useState("");
  const [cPhone,   setCPhone]   = useState("");
  const [cNotes,   setCNotes]   = useState("");
  const [iAmt,     setIAmt]     = useState("");
  const [iUnknown, setIUnknown] = useState(false);
  const [dIdx,     setDIdx]     = useState(0);
  const [payM,     setPayM]     = useState("");
  const [done,     setDone]     = useState(false);
  const [doneNo,   setDoneNo]   = useState("");

  const flash = (m,t="success")=>{ setToast({m,t}); setTimeout(()=>setToast(null),3200); };

  const earned = orders.filter(o=>o.status==="completed").reduce((s,o)=>s+(o.itemUnknown?o.deliveryFee:(o.itemAmount||0)+o.deliveryFee),0);
  const cnt    = { p:orders.filter(o=>o.status==="pending").length, i:orders.filter(o=>o.status==="in-progress").length, c:orders.filter(o=>o.status==="completed").length };

  const dFee    = DFEES[dIdx].fee;
  const iAmt$   = iUnknown ? 0 : (parseFloat(iAmt)||0);
  const total   = iAmt$ + dFee;

  const resetForm = () => {
    setStep(1); setOItems([{name:"",qty:1,notes:""}]);
    setPickup(""); setDelivery(""); setCName(""); setCPhone(""); setCNotes("");
    setIAmt(""); setIUnknown(false); setDIdx(0); setPayM("");
    setDone(false); setDoneNo("");
  };

  const submit = () => {
    if(!cName||!cPhone||!pickup||!delivery||!oItems[0].name||!payM){
      flash("Please complete all required fields","error"); return;
    }
    const no=`YE-${String(orders.length+1).padStart(3,"0")}`;
    setOrders([{id:Date.now(),orderNo:no,clientName:cName,clientPhone:cPhone,
      items:oItems.filter(i=>i.name),pickupLocation:pickup,deliveryAddress:delivery,
      clientNotes:cNotes,itemAmount:iAmt$,itemUnknown:iUnknown,
      deliveryFee:dFee,payMethod:payM,status:"pending",
      time:new Date().toISOString().slice(0,16).replace("T"," ")
    },...orders]);
    setDoneNo(no); setDone(true);
  };

  // ════ HOME ═══════════════════════════════════════════════════
  if(view==="home") return(
    <div style={{minHeight:"100vh",background:`linear-gradient(155deg,${C.p900} 0%,${C.p700} 55%,${C.p500} 100%)`,
      display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
      padding:24,position:"relative",overflow:"hidden"}}>
      {[[220,"-60px","-60px"],[300,"50%","58%"],[130,"8%","72%"]].map(([s,t,l],i)=>(
        <div key={i} style={{position:"absolute",width:s,height:s,borderRadius:"50%",background:"rgba(255,255,255,0.04)",top:t,left:l}}/>
      ))}
      <div style={{textAlign:"center",marginBottom:52,position:"relative"}}>
        <div style={{fontSize:64,marginBottom:10}}>🚀</div>
        <h1 style={{color:C.white,fontSize:36,fontFamily:"Georgia,serif",margin:"0 0 4px",letterSpacing:-1}}>Yafika Errands</h1>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:6}}>
          <div style={{width:28,height:2,background:C.gold,borderRadius:2}}/>
          <p style={{color:C.p300,fontSize:12,fontFamily:"'Trebuchet MS',sans-serif",margin:0,letterSpacing:2,textTransform:"uppercase"}}>Lusaka's Delivery Partner 🇿🇲</p>
          <div style={{width:28,height:2,background:C.gold,borderRadius:2}}/>
        </div>
      </div>
      <div style={{width:"100%",maxWidth:360,display:"flex",flexDirection:"column",gap:14}}>
        <button onClick={()=>{resetForm();setView("client");}} style={{
          background:C.gold,color:C.dark,border:"none",borderRadius:14,
          padding:"18px 24px",fontSize:17,fontWeight:700,cursor:"pointer",
          fontFamily:"'Trebuchet MS',sans-serif",boxShadow:`0 8px 32px rgba(245,158,11,0.45)`,
          display:"flex",alignItems:"center",justifyContent:"center",gap:10}}>
          <span style={{fontSize:22}}>📦</span> Place an Order
        </button>
        <button onClick={()=>setView("pin")} style={{
          background:"rgba(255,255,255,0.1)",color:C.white,
          border:"1.5px solid rgba(255,255,255,0.22)",borderRadius:14,
          padding:"18px 24px",fontSize:17,fontWeight:700,cursor:"pointer",
          fontFamily:"'Trebuchet MS',sans-serif",
          display:"flex",alignItems:"center",justifyContent:"center",gap:10}}>
          <span style={{fontSize:22}}>⚙️</span> Admin / Owner
        </button>
      </div>
      <p style={{color:"rgba(255,255,255,0.25)",fontSize:11,fontFamily:"sans-serif",marginTop:44,letterSpacing:1}}>YAFIKA ERRANDS © 2026</p>
    </div>
  );

  // ════ PIN ════════════════════════════════════════════════════
  if(view==="pin") return(
    <div style={{minHeight:"100vh",background:C.p50,display:"flex",flexDirection:"column",
      alignItems:"center",justifyContent:"center",padding:24}}>
      <button onClick={()=>setView("home")} style={{position:"absolute",top:20,left:20,background:"none",border:"none",color:C.p600,fontSize:22,cursor:"pointer"}}>←</button>
      <div style={{fontSize:52,marginBottom:14}}>🔐</div>
      <h2 style={{color:C.p800,fontFamily:"Georgia,serif",marginBottom:6}}>Admin Access</h2>
      <p style={{color:C.gray,fontSize:13,fontFamily:"'Trebuchet MS',sans-serif",marginBottom:22}}>Enter your 4-digit PIN</p>
      <input type="password" maxLength={4} placeholder="••••" value={pin}
        onChange={e=>{setPin(e.target.value);setPinErr(false);}}
        style={{...IS(),textAlign:"center",fontSize:30,letterSpacing:10,width:160,marginBottom:12}}/>
      {pinErr&&<p style={{color:C.danger,fontSize:12,fontFamily:"sans-serif",marginBottom:8}}>Wrong PIN — try 1234</p>}
      <button onClick={()=>{if(pin==="1234"){setView("admin");setPin("");}else setPinErr(true);}}
        style={{...PB(`linear-gradient(135deg,${C.p700},${C.p600})`),width:160,marginTop:4}}>Enter</button>
      <p style={{color:C.p400,fontSize:11,marginTop:18,fontFamily:"sans-serif"}}>Default PIN: 1234</p>
    </div>
  );

  // ════ CLIENT ORDER FLOW ═══════════════════════════════════════
  if(view==="client"){

    // success screen
    if(done) return(
      <div style={{minHeight:"100vh",background:`linear-gradient(155deg,${C.p800},${C.p500})`,
        display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center"}}>
        <div style={{fontSize:72,marginBottom:14}}>🎉</div>
        <h2 style={{color:C.white,fontFamily:"Georgia,serif",fontSize:28,marginBottom:8}}>Order Placed!</h2>
        <p style={{color:C.p300,fontFamily:"'Trebuchet MS',sans-serif",marginBottom:4,fontSize:14}}>Your order number is</p>
        <div style={{background:C.gold,color:C.dark,borderRadius:12,padding:"12px 32px",fontSize:26,fontWeight:700,fontFamily:"Georgia,serif",marginBottom:18}}>{doneNo}</div>
        <div style={{background:"rgba(255,255,255,0.1)",borderRadius:12,padding:16,marginBottom:24,maxWidth:300}}>
          <div style={{color:C.white,fontSize:13,fontFamily:"'Trebuchet MS',sans-serif",lineHeight:1.7}}>
            We will contact you on <strong>{cPhone}</strong> to confirm your order details before we start. 🙏
          </div>
        </div>
        <button onClick={resetForm} style={{...PB(C.gold,C.dark),width:220,marginBottom:10,borderRadius:12}}>Place Another Order</button>
        <button onClick={()=>{resetForm();setView("home");}} style={{...PB("rgba(255,255,255,0.12)",C.white),width:220,borderRadius:12,border:"1px solid rgba(255,255,255,0.2)"}}>Back to Home</button>
      </div>
    );

    const STEPS=["Items","Pickup","Cost & Payment","Contact & Delivery","Confirm"];
    return(
      <div style={{minHeight:"100vh",background:C.p50,fontFamily:"'Trebuchet MS',sans-serif"}}>
        {/* header */}
        <div style={{background:`linear-gradient(135deg,${C.p800},${C.p600})`}}>
          <div style={{maxWidth:480,margin:"0 auto",padding:"14px 16px"}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:14}}>
              <button onClick={()=>step>1?setStep(step-1):setView("home")}
                style={{background:"rgba(255,255,255,0.15)",border:"none",borderRadius:8,color:C.white,padding:"6px 12px",cursor:"pointer",fontSize:16}}>←</button>
              <div>
                <div style={{color:"rgba(255,255,255,0.5)",fontSize:11,letterSpacing:2,textTransform:"uppercase"}}>Step {step} of 5</div>
                <div style={{color:C.white,fontSize:18,fontWeight:700}}>{STEPS[step-1]}</div>
              </div>
              <div style={{marginLeft:"auto",color:C.gold,fontSize:14,fontWeight:700}}>Yafika 🚀</div>
            </div>
            <div style={{display:"flex",gap:4}}>
              {STEPS.map((_,i)=>(
                <div key={i} style={{flex:1,height:4,borderRadius:4,transition:"background .3s",
                  background:i<step?C.gold:"rgba(255,255,255,0.2)"}}/>
              ))}
            </div>
          </div>
        </div>

        <div style={{maxWidth:480,margin:"0 auto",padding:"20px 16px"}}>

          {/* ── STEP 1: Items ── */}
          {step===1&&(
            <div>
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:16}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>What do you need? 🛍️</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 16px"}}>List the items you want us to get for you.</p>
                {oItems.map((item,idx)=>(
                  <div key={idx} style={{background:C.p50,borderRadius:10,padding:14,marginBottom:12,border:`1px solid ${C.p100}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                      <span style={{fontSize:12,fontWeight:700,color:C.p600}}>ITEM {idx+1}</span>
                      {oItems.length>1&&<button onClick={()=>setOItems(oItems.filter((_,i)=>i!==idx))}
                        style={{background:"none",border:"none",color:C.danger,cursor:"pointer",fontSize:20,lineHeight:1}}>×</button>}
                    </div>
                    <div style={{marginBottom:8}}>
                      <label style={LS}>Item Type *</label>
                      <select value={item.name} onChange={e=>{const n=[...oItems];n[idx].name=e.target.value;setOItems(n);}}
                        style={{...IS(),background:"#fff"}}>
                        <option value="">Select type...</option>
                        {ITEMS.map(i=><option key={i}>{i}</option>)}
                      </select>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"76px 1fr",gap:8}}>
                      <div>
                        <label style={LS}>Qty</label>
                        <input type="number" min={1} value={item.qty}
                          onChange={e=>{const n=[...oItems];n[idx].qty=e.target.value;setOItems(n);}}
                          style={IS()}/>
                      </div>
                      <div>
                        <label style={LS}>Description</label>
                        <input placeholder="e.g. 2kg tomatoes, ripe" value={item.notes}
                          onChange={e=>{const n=[...oItems];n[idx].notes=e.target.value;setOItems(n);}}
                          style={IS()}/>
                      </div>
                    </div>
                  </div>
                ))}
                <button onClick={()=>setOItems([...oItems,{name:"",qty:1,notes:""}])}
                  style={{...PB(C.p100,C.p700,{border:`1.5px dashed ${C.p400}`,fontSize:13,borderRadius:10})}} >+ Add Another Item</button>
              </div>
              <button onClick={()=>{if(!oItems[0].name){flash("Select at least one item","error");return;}setStep(2);}}
                style={{...PB(`linear-gradient(135deg,${C.p700},${C.p500})`),boxShadow:`0 4px 20px ${C.p500}55`}}>Continue →</button>
            </div>
          )}

          {/* ── STEP 2: Pickup ── */}
          {step===2&&(
            <div>
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:16}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>Where to pick up? 📍</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 16px"}}>Which shop or place should we go to?</p>
                <div style={{marginBottom:16}}>
                  <label style={LS}>Shop / Location Name *</label>
                  <input placeholder="e.g. Shoprite Manda Hill, Soweto Market…" value={pickup}
                    onChange={e=>setPickup(e.target.value)} style={IS()}/>
                  <p style={{color:C.gray,fontSize:11,marginTop:4}}>Include the area or road for accuracy.</p>
                </div>
                <label style={LS}>Popular Spots — tap to fill</label>
                <div style={{display:"flex",flexWrap:"wrap",gap:8,marginTop:6}}>
                  {SPOTS.map(loc=>(
                    <button key={loc} onClick={()=>setPickup(loc)} style={{
                      background:pickup===loc?C.p600:C.p50,color:pickup===loc?C.white:C.p700,
                      border:`1px solid ${C.p300}`,borderRadius:20,padding:"5px 12px",
                      fontSize:12,cursor:"pointer",fontFamily:"'Trebuchet MS',sans-serif"}}>{loc}</button>
                  ))}
                </div>
              </div>
              <button onClick={()=>{if(!pickup){flash("Enter pickup location","error");return;}setStep(3);}}
                style={{...PB(`linear-gradient(135deg,${C.p700},${C.p500})`),boxShadow:`0 4px 20px ${C.p500}55`}}>Continue →</button>
            </div>
          )}

          {/* ── STEP 3: Cost & Payment ── */}
          {step===3&&(
            <div>
              {/* Item Cost */}
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:14}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>Item Cost 🛒</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 14px"}}>How much will the items cost in total?</p>

                {/* Unknown toggle */}
                <button onClick={()=>{setIUnknown(!iUnknown);setIAmt("");}} style={{
                  display:"flex",alignItems:"center",gap:10,background:iUnknown?C.p100:C.lightG,
                  border:`2px solid ${iUnknown?C.p500:"#ddd"}`,borderRadius:10,
                  padding:"10px 14px",cursor:"pointer",width:"100%",marginBottom:12,textAlign:"left"}}>
                  <div style={{width:20,height:20,borderRadius:"50%",background:iUnknown?C.p600:"#ddd",
                    display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                    {iUnknown&&<div style={{width:8,height:8,borderRadius:"50%",background:C.white}}/>}
                  </div>
                  <div>
                    <div style={{fontSize:13,fontWeight:700,color:iUnknown?C.p700:C.dark,fontFamily:"'Trebuchet MS',sans-serif"}}>I don't know the item cost yet</div>
                    <div style={{fontSize:11,color:C.gray,fontFamily:"sans-serif"}}>We'll confirm the amount before purchasing</div>
                  </div>
                </button>

                {!iUnknown&&(
                  <div>
                    <label style={LS}>Estimated Item Amount (ZMW) *</label>
                    <input type="number" min={0} placeholder="e.g. 250" value={iAmt}
                      onChange={e=>setIAmt(e.target.value)} style={IS()}/>
                    <p style={{color:C.gray,fontSize:11,marginTop:4}}>Enter your best estimate — we'll confirm before buying.</p>
                  </div>
                )}
              </div>

              {/* Delivery Fee */}
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:14}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>Delivery Distance 🚗</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 14px"}}>Select how far we need to travel to deliver.</p>
                <div style={{display:"flex",flexDirection:"column",gap:8}}>
                  {DFEES.map((df,i)=>(
                    <button key={i} onClick={()=>setDIdx(i)} style={{
                      display:"flex",justifyContent:"space-between",alignItems:"center",
                      background:dIdx===i?C.p100:C.lightG,
                      border:`2px solid ${dIdx===i?C.p500:"transparent"}`,
                      borderRadius:10,padding:"12px 14px",cursor:"pointer",textAlign:"left"}}>
                      <div style={{display:"flex",alignItems:"center",gap:10}}>
                        <div style={{width:18,height:18,borderRadius:"50%",background:dIdx===i?C.p600:"#ccc",
                          display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                          {dIdx===i&&<div style={{width:7,height:7,borderRadius:"50%",background:C.white}}/>}
                        </div>
                        <span style={{fontSize:13,color:C.dark,fontFamily:"'Trebuchet MS',sans-serif"}}>{df.label}</span>
                      </div>
                      <span style={{fontSize:14,fontWeight:700,color:C.p700,fontFamily:"'Trebuchet MS',sans-serif"}}>K{df.fee}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Cost Summary */}
              <div style={{background:`linear-gradient(135deg,${C.p800},${C.p600})`,borderRadius:14,padding:18,marginBottom:14}}>
                <div style={{color:C.p300,fontSize:11,letterSpacing:2,textTransform:"uppercase",fontFamily:"sans-serif",marginBottom:12}}>Cost Summary</div>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                  <span style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontFamily:"sans-serif"}}>Item Cost</span>
                  <span style={{color:C.white,fontWeight:700,fontSize:13,fontFamily:"sans-serif"}}>
                    {iUnknown?"TBD (confirmed before purchase)":`K${iAmt$}`}
                  </span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:12,paddingBottom:12,borderBottom:"1px solid rgba(255,255,255,0.15)"}}>
                  <span style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontFamily:"sans-serif"}}>Delivery Fee</span>
                  <span style={{color:C.white,fontWeight:700,fontSize:13,fontFamily:"sans-serif"}}>K{dFee}</span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between"}}>
                  <span style={{color:C.gold,fontWeight:700,fontSize:15,fontFamily:"sans-serif"}}>Total to Pay</span>
                  <span style={{color:C.gold,fontWeight:700,fontSize:20,fontFamily:"sans-serif"}}>
                    {iUnknown?`K${dFee} + items`:`K${total}`}
                  </span>
                </div>
              </div>

              {/* Payment Method */}
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:16}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>How will you pay? 💰</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 14px"}}>Choose your preferred payment method.</p>
                <div style={{display:"flex",flexDirection:"column",gap:10}}>
                  {PAY.map(pm=>(
                    <button key={pm.id} onClick={()=>setPayM(pm.id)} style={{
                      display:"flex",alignItems:"center",gap:14,
                      background:payM===pm.id?pm.bg:"#f8f8f8",
                      border:`2px solid ${payM===pm.id?pm.bg:"#e5e7eb"}`,
                      borderRadius:12,padding:"13px 16px",cursor:"pointer",textAlign:"left",
                      transition:"all .15s"}}>
                      <span style={{fontSize:26}}>{pm.icon}</span>
                      <div style={{flex:1}}>
                        <div style={{fontSize:14,fontWeight:700,
                          color:payM===pm.id?pm.fg:C.dark,
                          fontFamily:"'Trebuchet MS',sans-serif"}}>{pm.label}</div>
                        {pm.ussd&&<div style={{fontSize:11,
                          color:payM===pm.id?pm.fg+"cc":C.gray,
                          fontFamily:"sans-serif",marginTop:2}}>Dial {pm.ussd}</div>}
                      </div>
                      <div style={{width:20,height:20,borderRadius:"50%",
                        background:payM===pm.id?pm.fg+"33":"#ddd",
                        border:`2px solid ${payM===pm.id?pm.fg:"#ccc"}`,
                        display:"flex",alignItems:"center",justifyContent:"center"}}>
                        {payM===pm.id&&<div style={{width:8,height:8,borderRadius:"50%",background:pm.fg}}/>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <button onClick={()=>{
                if(!payM){flash("Please select a payment method","error");return;}
                if(!iUnknown&&!iAmt){flash("Enter item amount or select 'I don't know'","error");return;}
                setStep(4);
              }} style={{...PB(`linear-gradient(135deg,${C.p700},${C.p500})`),boxShadow:`0 4px 20px ${C.p500}55`}}>Continue →</button>
            </div>
          )}

          {/* ── STEP 4: Contact & Delivery ── */}
          {step===4&&(
            <div>
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:16}}>
                <h3 style={{color:C.p800,margin:"0 0 4px",fontSize:17}}>Contact & Delivery Details 👤</h3>
                <p style={{color:C.gray,fontSize:13,margin:"0 0 16px"}}>So we can reach you and deliver to the right place.</p>
                {[
                  {label:"Your Full Name *",     val:cName,    set:setCName,    ph:"e.g. Chanda Mwale",                             type:"text"},
                  {label:"Phone Number (WhatsApp preferred) *", val:cPhone, set:setCPhone, ph:"e.g. 0977 123 456",                  type:"tel"},
                  {label:"Delivery Address *",   val:delivery, set:setDelivery, ph:"e.g. House 14, Woodlands Extension, near stadium",type:"text"},
                ].map(f=>(
                  <div key={f.label} style={{marginBottom:14}}>
                    <label style={LS}>{f.label}</label>
                    <input type={f.type} placeholder={f.ph} value={f.val}
                      onChange={e=>f.set(e.target.value)} style={IS()}/>
                  </div>
                ))}
                <div>
                  <label style={LS}>Extra Notes (optional)</label>
                  <textarea placeholder="Specific brands, gate colour, budget cap, any special instructions…"
                    value={cNotes} onChange={e=>setCNotes(e.target.value)}
                    style={{...IS(),height:72,resize:"vertical"}}/>
                </div>
              </div>
              <button onClick={()=>{if(!cName||!cPhone||!delivery){flash("Fill all required fields","error");return;}setStep(5);}}
                style={{...PB(`linear-gradient(135deg,${C.p700},${C.p500})`),boxShadow:`0 4px 20px ${C.p500}55`}}>Review Order →</button>
            </div>
          )}

          {/* ── STEP 5: Confirm ── */}
          {step===5&&(
            <div>
              <div style={{background:C.white,borderRadius:14,padding:20,boxShadow:`0 2px 16px ${C.p500}18`,marginBottom:14}}>
                <h3 style={{color:C.p800,margin:"0 0 16px",fontSize:17}}>Confirm Your Order ✅</h3>
                {[
                  ["🛍️","Items",      oItems.filter(i=>i.name).map(i=>`${i.qty}× ${i.name}${i.notes?` — ${i.notes}`:""}`).join("\n")],
                  ["📍","Pick Up From", pickup],
                  ["🏠","Deliver To",   delivery],
                  ["👤","Your Name",    cName],
                  ["📞","Phone",        cPhone],
                ].map(([icon,k,v])=>(
                  <div key={k} style={{display:"flex",gap:12,paddingBottom:12,marginBottom:12,borderBottom:`1px solid ${C.p100}`}}>
                    <span style={{fontSize:18,flexShrink:0}}>{icon}</span>
                    <div>
                      <div style={{fontSize:10,color:C.p500,fontWeight:700,textTransform:"uppercase",letterSpacing:.5,marginBottom:2}}>{k}</div>
                      <div style={{fontSize:13,color:C.dark,lineHeight:1.6,whiteSpace:"pre-line"}}>{v}</div>
                    </div>
                  </div>
                ))}

                {/* Payment badge */}
                {(()=>{const pm=PAY.find(p=>p.id===payM); return pm?(
                  <div style={{display:"flex",alignItems:"center",gap:10,background:pm.bg,borderRadius:10,padding:"10px 14px",marginBottom:12}}>
                    <span style={{fontSize:22}}>{pm.icon}</span>
                    <div>
                      <div style={{fontSize:13,fontWeight:700,color:pm.fg,fontFamily:"'Trebuchet MS',sans-serif"}}>{pm.label}</div>
                      {pm.ussd&&<div style={{fontSize:11,color:pm.fg,opacity:.8,fontFamily:"sans-serif"}}>Dial {pm.ussd}</div>}
                    </div>
                  </div>
                ):null;})()}

                {/* Cost breakdown */}
                <div style={{background:`linear-gradient(135deg,${C.p800},${C.p600})`,borderRadius:12,padding:16}}>
                  <div style={{color:C.p300,fontSize:10,letterSpacing:2,textTransform:"uppercase",fontFamily:"sans-serif",marginBottom:10}}>Cost Breakdown</div>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                    <span style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontFamily:"sans-serif"}}>Item Cost</span>
                    <span style={{color:C.white,fontWeight:700,fontSize:13,fontFamily:"sans-serif"}}>
                      {iUnknown?"TBD":`K${iAmt$}`}
                    </span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:10,paddingBottom:10,borderBottom:"1px solid rgba(255,255,255,0.15)"}}>
                    <span style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontFamily:"sans-serif"}}>Delivery Fee</span>
                    <span style={{color:C.white,fontWeight:700,fontSize:13,fontFamily:"sans-serif"}}>K{dFee}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between"}}>
                    <span style={{color:C.gold,fontWeight:700,fontSize:14,fontFamily:"sans-serif"}}>Total</span>
                    <span style={{color:C.gold,fontWeight:700,fontSize:20,fontFamily:"sans-serif"}}>
                      {iUnknown?`K${dFee} + items`:`K${total}`}
                    </span>
                  </div>
                </div>

                {cNotes&&<div style={{background:C.goldL,borderRadius:8,padding:10,fontSize:13,color:"#78350F",marginTop:12}}>📝 <strong>Notes:</strong> {cNotes}</div>}
              </div>

              <div style={{background:C.p100,borderRadius:10,padding:12,marginBottom:14,fontSize:13,color:C.p700,textAlign:"center",lineHeight:1.6}}>
                💜 We'll call <strong>{cPhone}</strong> to confirm before we start. {iUnknown&&"We'll also confirm the item amount."}
              </div>
              <button onClick={submit}
                style={{...PB(`linear-gradient(135deg,${C.gold},${C.goldD})`,C.dark),fontSize:16,boxShadow:`0 4px 24px rgba(245,158,11,0.45)`}}>
                🚀 Place Order Now
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ════ ADMIN PANEL ═════════════════════════════════════════════
  if(view==="admin"){
    const list =
      aTab==="pending"     ? orders.filter(o=>o.status==="pending") :
      aTab==="in-progress" ? orders.filter(o=>o.status==="in-progress") :
      orders;

    return(
      <div style={{minHeight:"100vh",background:C.p50}}>
        {toast&&(
          <div style={{position:"fixed",top:16,right:16,zIndex:9999,
            background:toast.t==="error"?C.danger:C.p700,color:C.white,
            padding:"10px 18px",borderRadius:8,fontSize:13,fontFamily:"sans-serif",
            boxShadow:"0 4px 20px rgba(0,0,0,0.2)"}}>{toast.m}</div>
        )}

        {/* admin header */}
        <div style={{background:`linear-gradient(135deg,${C.p900},${C.p700})`,position:"sticky",top:0,zIndex:50}}>
          <div style={{maxWidth:480,margin:"0 auto"}}>
            <div style={{padding:"14px 16px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <button onClick={()=>setView("home")} style={{background:"rgba(255,255,255,0.12)",border:"none",borderRadius:8,color:C.white,padding:"4px 10px",cursor:"pointer",fontSize:16}}>←</button>
                <div>
                  <div style={{color:C.p300,fontSize:10,letterSpacing:2,textTransform:"uppercase"}}>Admin Panel</div>
                  <div style={{color:C.white,fontSize:17,fontWeight:700}}>Yafika Errands 🚀</div>
                </div>
              </div>
              <div style={{background:C.gold,color:C.dark,borderRadius:8,padding:"6px 12px",fontSize:13,fontWeight:700,fontFamily:"'Trebuchet MS',sans-serif"}}>K{earned.toLocaleString()}</div>
            </div>
            <div style={{display:"flex",borderTop:"1px solid rgba(255,255,255,0.1)"}}>
              {[["dashboard","📊"],["orders","📋 All"],["pending","⏳"],["in-progress","🔄"]].map(([k,label])=>(
                <button key={k} onClick={()=>setATab(k)} style={{
                  flex:1,background:"none",border:"none",
                  color:aTab===k?C.gold:"rgba(255,255,255,0.45)",
                  padding:"9px 2px",fontSize:11,cursor:"pointer",
                  fontFamily:"'Trebuchet MS',sans-serif",
                  borderBottom:aTab===k?`2px solid ${C.gold}`:"2px solid transparent",
                  textAlign:"center",whiteSpace:"nowrap"}}>{label}</button>
              ))}
            </div>
          </div>
        </div>

        <div style={{maxWidth:480,margin:"0 auto",padding:16}}>
          {aTab==="dashboard"&&(
            <div>
              <div style={{background:`linear-gradient(135deg,${C.p800},${C.p600})`,borderRadius:16,padding:"22px 20px",marginBottom:16,position:"relative",overflow:"hidden"}}>
                <div style={{position:"absolute",top:-40,right:-40,width:140,height:140,borderRadius:"50%",background:"rgba(255,255,255,0.05)"}}/>
                <div style={{color:C.p300,fontSize:11,textTransform:"uppercase",letterSpacing:2,fontFamily:"sans-serif"}}>Total Earned</div>
                <div style={{color:C.gold,fontSize:44,fontWeight:700,fontFamily:"Georgia,serif",margin:"4px 0"}}>K{earned.toLocaleString()}</div>
                <div style={{color:"rgba(255,255,255,0.45)",fontSize:12,fontFamily:"sans-serif"}}>From {cnt.c} completed errands</div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>
                {[["⏳","Pending",cnt.p,C.warning,"#FFFBF0"],["🔄","Active",cnt.i,"#3B82F6","#EFF6FF"],["✅","Done",cnt.c,C.success,"#F0FBF4"]].map(([icon,label,val,color,bg])=>(
                  <div key={label} style={{background:bg,borderRadius:12,padding:"14px 10px",textAlign:"center",border:`1px solid ${color}22`}}>
                    <div style={{fontSize:20}}>{icon}</div>
                    <div style={{fontSize:26,fontWeight:700,color,fontFamily:"Georgia,serif"}}>{val}</div>
                    <div style={{fontSize:10,color:C.gray,fontFamily:"sans-serif",textTransform:"uppercase",letterSpacing:.5}}>{label}</div>
                  </div>
                ))}
              </div>
              {cnt.p>0&&(
                <div style={{background:"#FEF3C7",border:"1px solid #FCD34D",borderRadius:12,padding:14,marginBottom:14}}>
                  <div style={{fontWeight:700,color:"#92400E",fontFamily:"sans-serif",fontSize:13,marginBottom:2}}>🔔 {cnt.p} New Order{cnt.p>1?"s":""} Waiting!</div>
                  <div style={{fontSize:12,color:"#78350F",fontFamily:"sans-serif"}}>Check ⏳ Pending to review and accept.</div>
                </div>
              )}
              <div style={{marginBottom:8,fontSize:11,fontWeight:700,color:C.p500,fontFamily:"sans-serif",textTransform:"uppercase",letterSpacing:1}}>Recent Orders</div>
              {orders.slice(0,3).map(o=><ACard key={o.id} order={o} onClick={()=>setSel(o)}/>)}
            </div>
          )}
          {(aTab==="orders"||aTab==="pending"||aTab==="in-progress")&&(
            <div>
              {list.length===0
                ?<div style={{textAlign:"center",padding:48,color:C.gray,fontFamily:"sans-serif"}}>No orders here</div>
                :list.map(o=><ACard key={o.id} order={o} onClick={()=>setSel(o)}/>)
              }
            </div>
          )}
        </div>

        {/* Order detail modal */}
        {sel&&(
          <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.65)",zIndex:200,display:"flex",alignItems:"flex-end"}}
            onClick={e=>e.target===e.currentTarget&&setSel(null)}>
            <div style={{background:C.white,borderRadius:"20px 20px 0 0",width:"100%",maxWidth:480,margin:"0 auto",padding:"24px 20px",maxHeight:"92vh",overflowY:"auto"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                <div>
                  <div style={{fontSize:11,color:C.p400,fontFamily:"sans-serif",letterSpacing:1}}>{sel.orderNo}</div>
                  <div style={{fontSize:20,fontWeight:700,color:C.dark}}>{sel.clientName}</div>
                </div>
                <button onClick={()=>setSel(null)} style={{background:C.p50,border:"none",borderRadius:"50%",width:32,height:32,cursor:"pointer",fontSize:16}}>✕</button>
              </div>

              <div style={{background:C.p50,borderRadius:12,padding:14,marginBottom:14}}>
                {[
                  ["📞","Phone",       sel.clientPhone],
                  ["🛍️","Items",      sel.items?.map(i=>`${i.qty}× ${i.name}${i.notes?` — ${i.notes}`:""}`).join(" | ")],
                  ["📍","Pick Up",     sel.pickupLocation],
                  ["🏠","Deliver To",  sel.deliveryAddress],
                  ["🕐","Order Time",  sel.time],
                ].map(([icon,k,v])=>(
                  <div key={k} style={{display:"flex",gap:10,paddingBottom:10,marginBottom:10,borderBottom:`1px solid ${C.p100}`}}>
                    <span style={{fontSize:16,flexShrink:0}}>{icon}</span>
                    <div>
                      <div style={{fontSize:10,color:C.p500,fontWeight:700,textTransform:"uppercase",letterSpacing:.5}}>{k}</div>
                      <div style={{fontSize:13,color:C.dark,marginTop:1}}>{v}</div>
                    </div>
                  </div>
                ))}

                {/* Cost breakdown */}
                <div style={{background:`linear-gradient(135deg,${C.p800},${C.p600})`,borderRadius:10,padding:14,marginBottom:12}}>
                  <div style={{color:C.p300,fontSize:10,letterSpacing:2,textTransform:"uppercase",fontFamily:"sans-serif",marginBottom:8}}>Cost Breakdown</div>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                    <span style={{color:"rgba(255,255,255,0.7)",fontSize:12,fontFamily:"sans-serif"}}>Item Cost</span>
                    <span style={{color:C.white,fontWeight:700,fontSize:12,fontFamily:"sans-serif"}}>{sel.itemUnknown?"TBD":`K${sel.itemAmount||0}`}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,paddingBottom:8,borderBottom:"1px solid rgba(255,255,255,0.15)"}}>
                    <span style={{color:"rgba(255,255,255,0.7)",fontSize:12,fontFamily:"sans-serif"}}>Delivery Fee</span>
                    <span style={{color:C.white,fontWeight:700,fontSize:12,fontFamily:"sans-serif"}}>K{sel.deliveryFee||0}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between"}}>
                    <span style={{color:C.gold,fontWeight:700,fontSize:13,fontFamily:"sans-serif"}}>Total</span>
                    <span style={{color:C.gold,fontWeight:700,fontSize:17,fontFamily:"sans-serif"}}>{sel.itemUnknown?`K${sel.deliveryFee||0} + items`:`K${(sel.itemAmount||0)+(sel.deliveryFee||0)}`}</span>
                  </div>
                </div>

                {/* Payment badge */}
                {(()=>{const pm=PAY.find(p=>p.id===sel.payMethod); return pm?(
                  <div style={{display:"flex",alignItems:"center",gap:10,background:pm.bg,borderRadius:8,padding:"10px 12px"}}>
                    <span style={{fontSize:20}}>{pm.icon}</span>
                    <div>
                      <div style={{color:pm.fg,fontSize:12,fontWeight:700,fontFamily:"sans-serif"}}>{pm.label}</div>
                      {pm.ussd&&<div style={{color:pm.fg,fontSize:10,fontFamily:"sans-serif",opacity:.8}}>Dial {pm.ussd}</div>}
                    </div>
                  </div>
                ):null;})()}
              </div>

              <div style={{marginBottom:10,fontSize:11,fontWeight:700,color:C.gray,fontFamily:"sans-serif",textTransform:"uppercase"}}>Update Status</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
                {["pending","in-progress","completed","cancelled"].map(s=>(
                  <button key={s} onClick={()=>{
                    setOrders(orders.map(o=>o.id===sel.id?{...o,status:s}:o));
                    setSel({...sel,status:s}); flash(`Status → ${s}`);
                  }} style={{
                    background:sel.status===s?C.p700:C.p50,color:sel.status===s?C.white:C.p700,
                    border:`1px solid ${C.p300}`,borderRadius:8,padding:"9px 6px",fontSize:12,
                    cursor:"pointer",fontFamily:"'Trebuchet MS',sans-serif",textTransform:"capitalize",fontWeight:600}}>{s}</button>
                ))}
              </div>
              {sel.clientPhone&&(
                <a href={`https://wa.me/260${sel.clientPhone.replace(/^0/,"")}`} target="_blank" rel="noreferrer"
                  style={{display:"block",textAlign:"center",background:"#25D366",color:C.white,borderRadius:10,padding:"11px",fontSize:14,textDecoration:"none",fontFamily:"'Trebuchet MS',sans-serif",fontWeight:700,marginBottom:8}}>
                  💬 WhatsApp Client
                </a>
              )}
              <button onClick={()=>{setOrders(orders.filter(o=>o.id!==sel.id));setSel(null);flash("Deleted","error");}}
                style={{...PB(C.white,C.danger,{border:`1px solid ${C.danger}`})}}>🗑 Delete Order</button>
            </div>
          </div>
        )}
      </div>
    );
  }
  return null;
}

function ACard({order,onClick}){
  const s  = STATUS[order.status]||STATUS.pending;
  const pm = PAY.find(p=>p.id===order.payMethod);
  const total = order.itemUnknown ? `K${order.deliveryFee||0}+` : `K${(order.itemAmount||0)+(order.deliveryFee||0)}`;
  return(
    <div onClick={onClick} style={{background:C.white,borderRadius:12,padding:"14px 16px",marginBottom:10,
      boxShadow:`0 2px 10px ${C.p500}15`,cursor:"pointer",borderLeft:`4px solid ${s.dot}`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div style={{flex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:3,flexWrap:"wrap"}}>
            <span style={{fontSize:11,color:C.p400,fontFamily:"sans-serif",fontWeight:700}}>{order.orderNo}</span>
            <span style={{background:s.bg,color:s.text,borderRadius:20,padding:"2px 8px",fontSize:10,fontFamily:"sans-serif",textTransform:"capitalize"}}>{order.status}</span>
            {pm&&<span style={{background:pm.bg,color:pm.fg,borderRadius:20,padding:"2px 8px",fontSize:10,fontFamily:"sans-serif"}}>{pm.icon} {pm.id.toUpperCase()}</span>}
          </div>
          <div style={{fontWeight:700,fontSize:15,color:C.dark,marginBottom:3}}>{order.clientName}</div>
          <div style={{fontSize:12,color:C.gray,fontFamily:"sans-serif"}}>📍 {order.pickupLocation}</div>
          <div style={{fontSize:12,color:C.gray,fontFamily:"sans-serif",marginTop:2}}>🏠 {order.deliveryAddress}</div>
        </div>
        <div style={{textAlign:"right",flexShrink:0,marginLeft:10}}>
          <div style={{fontWeight:700,fontSize:15,color:C.p700}}>{total}</div>
          <div style={{fontSize:10,color:C.gray,fontFamily:"sans-serif",marginTop:1}}>Del: K{order.deliveryFee||0}</div>
          <div style={{fontSize:10,color:C.gray,fontFamily:"sans-serif"}}>{order.time?.split(" ")[0]||""}</div>
        </div>
      </div>
    </div>
  );
}
